#include <stdio.h>
#include "util.h"
#include "symbol.h"
#include "env.h"

/*Lab4: Your implementation of lab4*/

E_enventry E_VarEntry(Ty_ty ty)
{
	E_enventry varEntry = checked_malloc(sizeof(*varEntry));
	varEntry->kind = E_varEntry;
	varEntry->u.var.ty = ty;
	varEntry->u.var.ROFlag = 0;
	return varEntry;
}

E_enventry E_ROVarEntry(Ty_ty ty)
{
	E_enventry varEntry = checked_malloc(sizeof(*varEntry));
	varEntry->kind = E_varEntry;
	varEntry->u.var.ty = ty;
	varEntry->u.var.ROFlag = 1;
	return varEntry;
}

E_enventry E_FunEntry(Ty_tyList formals, Ty_ty result)
{
	E_enventry funEntry = checked_malloc(sizeof(*funEntry));
	funEntry->kind = E_funEntry;
	funEntry->u.fun.formals = formals;
	funEntry->u.fun.result = result;
	return funEntry;
}

S_table E_base_tenv(void)
{
	S_table tenv_table = S_empty();
	S_symbol int_ty = S_Symbol("int");
	S_symbol string_ty = S_Symbol("string");

	S_enter(tenv_table, int_ty, Ty_Int());
	S_enter(tenv_table, string_ty, Ty_String());

	return tenv_table;
}

S_table E_base_venv(void)
{
	S_table venv_table = S_empty();

	return venv_table;
}

